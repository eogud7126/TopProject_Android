package we.meet.topproject.model

data class BoardModel (
    var title: String,
    var description: String,
    var createdDate: Long,
    var commentCnt: Int,
    var image: String)
{
}
